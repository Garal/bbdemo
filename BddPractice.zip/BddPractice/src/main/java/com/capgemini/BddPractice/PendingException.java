package com.capgemini.BddPractice;

public class PendingException extends Exception {

}
